<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'plasma_db' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'j!5WeIO)Gru0ovq3[V:;+zVJR:TQGrX/jst|/+1<^Jx:cn@+Xkp%yz[@0 lRa!M)' );
define( 'SECURE_AUTH_KEY',  '0FwxYVwglcH{0PP*aSqK<Esh]?3f*pK&-(XBHy<u9SS9*;*8iFi$5Q|.)0>NGc%R' );
define( 'LOGGED_IN_KEY',    'ZbK=#;ad]-xw.Wdq}F2v)aa7s4Le)xd<=.a78eoKbjM~W7&PEEY-A-P308MVqMD[' );
define( 'NONCE_KEY',        ' D1vjqn9kP{Ia@]?yTcK`lUKNZ[G-mw9EVVg~A_4UU0p5Y xDw+c^W$#?S}I:FKZ' );
define( 'AUTH_SALT',        'wz{!}4!3Kh?wKNZM4Jr%A`y{EZGADoum[$wwa6eh@Pw}agsmg`H,v9PH+C#iiD}S' );
define( 'SECURE_AUTH_SALT', 'Humd>;K6XL%o_$*T{H@-QN Uck_v8F(,q>;T] V@_9|yvQVRLF#lOqN{uwJ!Bv;.' );
define( 'LOGGED_IN_SALT',   'f/ftw?=eN4]u;!mhf(w?<vk*xnrG@;wrVn?0!~[9q4&xLG,l uG^W64Y9|?jZh>q' );
define( 'NONCE_SALT',       'MI4)dwt~X.WvP&5hH{U+QF`a2{5,U1lMDCGBQmm}`fy6w6 9|=sgunEmI/ !crH-' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
