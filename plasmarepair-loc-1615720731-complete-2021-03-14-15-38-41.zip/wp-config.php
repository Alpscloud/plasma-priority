<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'plasmarepair_db' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'root' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', '' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'qqtS,aTZk}q<|pl8X$NOBMj~{Uq>D%^M^-Al@OECTs v625>P<=`H^#?Uv7QX9(P' );
define( 'SECURE_AUTH_KEY',  '?kkR~^rV9adl*-<xP7j|#WA{nKotQjH =e(<2 H>RZ+{(7Q;!vnQoOub;sCzfCda' );
define( 'LOGGED_IN_KEY',    '3q:5nO rJc-UV|oIPu;Aa,V{dDxhC.?nCsLn=<<!zR.pY-Y0)?_{yTWZeap|h%/C' );
define( 'NONCE_KEY',        'JucCrz@q/gFU}F)Q_66NP/& jZeYG&IfAdh|J`M&yV7&GtO&-L,I<;8E{L<b!Yk/' );
define( 'AUTH_SALT',        '!X jaCu0adB,IxVg.Od>v7a=cRnaBoyj9REF]<_`zZj*%zbEf)98STD;&gLH),Ec' );
define( 'SECURE_AUTH_SALT', ' j#I?%k7EJD|M0cbS?Hz(Wz{qL+nxP4&|%K:wj/_Z/!sEmK:te kc,g[Q`--&#](' );
define( 'LOGGED_IN_SALT',   '4[t#h*ss4u!s[AsQhl}SWg#O<.{g+ol2<v=IR&me8jrb$Da6b;W3N/):2}gU3/n[' );
define( 'NONCE_SALT',       '}_Wh^7Lra:QF/I *L%>EOe=bD~;`t^I8]<Lg?BUJFU#h<1EmVE3U0v|1Go$bib|/' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
